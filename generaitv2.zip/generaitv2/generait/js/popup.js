/* Copyright (C) Relativity GmbH - All Rights Reserved
 * Unauthorized copying and distribution of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 */

let selectedtext;
let sourceC;
let currentTab

window.onload = async () => {

let [activeTab] = await chrome.tabs.query({active: true, currentWindow: true})


	currentTab = activeTab
	
	let opts = {
		target: {tabId: activeTab.id}, 
		func: () => window.getSelection().toString()
	}
	
	let [{result}] = await chrome.scripting.executeScript(opts)
	selectedtext = result
	console.log(selectedtext);
	
	const iframeEle = document.getElementById('myIframe')
	const loadingEle = document.getElementById('loadingS')
	iframeEle.addEventListener('load', () => {
		// Hide the loading indicator
		loadingEle.style.display = 'none'
	
		// Bring the iframe back
		// iframeEle.style.opacity = 1
		iframeEle.style.display = 'block'
	})
	
	setTimeout(() => iframeEle.src = `https://inventabot.com/chrome?id=${chrome.runtime.id}`, 200)
}

chrome.runtime.onMessage.addListener((request, sender) => {
	if (request.action == "getSourceReturn") sourceC = request.source
})



function copy(ttt) {
    chrome.tabs.query({ 
        currentWindow: true,
        active: true
    }).then(([tab]) => { 
        chrome.scripting.executeScript({
            target: {
                tabId: tab.id
            },
            func: copyHelp, 
            args: [ttt] 
        })
    })
};


async function copyHelp(tt) {
    const p = document.createElement('textarea');
    p.value = tt;
    p.style.right = '99999px';
    document.body.appendChild(p);
    p.select();
    document.execCommand('copy');
    document.body.removeChild(p);
}



chrome.runtime.onMessageExternal.addListener((request, sender, sendResponse) => {
	if (request.type == "opentab") {
		chrome.tabs.create({url: request.url})
	}else if (request.type == "copy") {
		copy(request.text);
	}else if (request.type == "bookmark") {
		chrome.bookmarks.create({'title': request.title, 'url': request.url})
	}
	else if (request.type == "screenshot") {
		chrome.tabs.captureVisibleTab(null, {}, image => {
			sendResponse({response: "Message received", image: image})
		})
		return true
	} 
	else if (request.type == "highlight") {
		sendResponse({highlighted: selectedtext})
		return true
	} 
	else if (request.type == "currenttab") {
		sendResponse({url: currentTab.url})
		return true
	} 
	else if (request.type == "language") {
		chrome.tabs.detectLanguage(currentTab.id, language => {
			sendResponse({language})
		})
		return true
	} 
	else if (request.type == "value") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			args: [request.id, request.value],
			func: (id, value) => {
				const element = document.getElementById(id)
				element.value = value
			}
		})
	}
	else if (request.type == "alert") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			func: msg => alert(msg),
			args: [request.value]
		})
	} 
	else if (request.type == "valueall") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			args: [request.value],
			func: value => {
				let context = document.querySelectorAll("input")
				context.forEach(item => item.value = value)
			}
		})
	}
	else if (request.type == "getvalue") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			func: id => document.getElementById(id).textContent,
			args: [request.id]
		}, ([{result}]) => {
			const zurueck = JSON.stringify(result)
			sendResponse({text: zurueck})
		})

		return true
	} 
	else if (request.type == "getvalueclass") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			func: selector => document.querySelector(selector).textContent,
			args: [request.class]
		}, ([{result}]) => {
			const zurueck = JSON.stringify(result)
			sendResponse({text: zurueck})
		})

		return true
	} 
	else if (request.type == "query") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			func: (selector, property) => document.querySelector(selector)[property],
			args: [request.selector, request.property]
		}, ([{result}]) => {
			const zurueck = JSON.stringify(result)
			sendResponse({text: zurueck})
		})

		return true
	} 
	else if (request.type == "getvaluetag") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			func: selector => document.querySelector(selector)?.textContent,
			args: [request.tag]
		}, ([{result}]) => {
			const zurueck = JSON.stringify(result)
			sendResponse({text: zurueck})
		})

		return true
	} 
	else if (request.type == "removebyid") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			func: id => document.getElementById(id)?.remove(),
			args: [request.id]
		})
	} 
	else if (request.type == "insertbyid") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			args: [request.id, request.text],
			func: (id, text) => {
				let tag = document.createElement("p")
				let txt = document.createTextNode(text)
				tag.appendChild(txt)
	
				let element = document.getElementById(id)
				element?.appendChild(tag)
			}
		})
	} 
	else if (request.type == "customscript") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			func: script => eval(script),
			args: [request.script],
			world: 'MAIN'
		})
	} 
	else if (request.type == "download") {
		chrome.downloads.download({url: request.url, filename: request.filename})
	} 
	else if (request.type == "pagesource") {
		chrome.scripting.executeScript({
			target: {tabId: currentTab.id},
			files: ['js/getPagesSource.js']
		}, () => {
			sendResponse({source: sourceC})
			
			let lastError = chrome.runtime.lastError
			if (lastError) {
				message.innerText = `There was an error injecting script : \n${lastError.message}`
			}
		})

		return true
	}else if (request.type == "tts") {
		chrome.tts.speak(request.text, {'lang': request.lang, 'rate': request.rate});
	} 
})